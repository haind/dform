<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Get started with jQuery dForm</title>
</head>
<body>
<script type="text/javascript" src="http://192.168.1.77/test/custom-form/jquery.dform-master/build-form-ew.php"></script>
</body>
</html>
